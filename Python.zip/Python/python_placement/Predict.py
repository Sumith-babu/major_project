from sklearn.neural_network import MLPClassifier
import numpy as np
import pandas as pd
import sys
import csv
from DBConnection import DBConnection

try:

    trainset = []
    database = DBConnection.getConnection()
    cursor = database.cursor()
    cursor.execute("select CodingSkills,AptitudeSkills,TechnicalSkills,Projects,Internships,AcademicPerformance,Placed from dataset")
    row = cursor.fetchall()
    y_train = []
    trainset.clear()
    y_train.clear()
    for r in row:
        x_train = []
        x_train.clear()
        x_train.append(float(r[0]))
        x_train.append(float(r[1]))
        x_train.append(float(r[2]))
        x_train.append(float(r[3]))
        x_train.append(float(r[4]))
        x_train.append(float(r[5]))
        y_train.append(r[6])
        trainset.append(x_train)
    trainset = np.array(trainset)

    # Train the model
    y_train = np.array(y_train)

    cs = sys.argv[1]
    ask = sys.argv[2]
    ts = sys.argv[3]
    prjcts = sys.argv[4]
    isk = sys.argv[5]
    ap = sys.argv[6]

    ta = ['CodingSkills','AptitudeSkills','TechnicalSkills','Projects','Internships','AcademicPerformance']
    tf = [int(cs),int(ask),int(ts),int(prjcts),int(isk),int(ap)]
    list = []
    list.clear();
    list.append(ta)
    list.append(tf)

    with open('live.csv', 'w') as csvFile:
        writer = csv.writer(csvFile)
        writer.writerows(list)

    csvFile.close()
    tf = pd.read_csv('live.csv')
    testdata = np.array(tf)
    # print("Ped=",testdata)
    testdata = testdata.reshape(len(testdata), -1)
    #print("Pedd=", testdata)

    # ANN    
    clf = MLPClassifier()
    clf.fit(trainset, y_train)
    result = clf.predict(testdata)
    print(result[0])



except Exception as e:
    print("Error=" + e.args[0])
    tb = sys.exc_info()[2]
    print(tb.tb_lineno)

