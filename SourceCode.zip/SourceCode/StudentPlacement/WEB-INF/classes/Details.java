
package CT;
import java.sql.*;

public class  Details
{

static String st1="No problem you can do it";
static String st2="Keep working and believing in your self..";
static String st3="It is okay to get wrong answer sometimes. You may have found the questions hard, but practice will make it easier. Try again";
static String st4="Just because you fail in this question doesn't mean that you are a failure. Keep working, you can do it. ";



public static String get(String id) {
	
	System.out.println(id+"--------------");


	String res="";
	if(id.equals("1")){
	res=st1;
	}
	else if(id.equals("2")){
	res=st2;
	
	}
	else if(id.equals("3")){
	res=st3;
	
	}else{
	res=st4;
	}


	return res;
}


	
	
	public static void main(String[] args) 
	{
	}

}



